Here is how to compile the program:
a. Open up the terminal
b. The python run file is on the ...............folder
c  Navigate to the folder
d. Run the $python3 “my-dns-client <host-name>” command.
e. $python3 client_program.py cnn.com 

Run the program with the following five command line arguments:
1. www.cnn.com
2. www.gmu.edu
3. vt.edu
4. youtube.com
5. www.example.com
