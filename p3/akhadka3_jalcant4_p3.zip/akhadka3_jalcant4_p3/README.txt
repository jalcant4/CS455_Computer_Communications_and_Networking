README

Run by calling

python3 ./p3_jalcant4_akhadka3.py